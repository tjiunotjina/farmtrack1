import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { Syringe, Stethoscope, Check, ClipboardList, Wallet, BadgeDollarSign, HeartPulse, Pencil, Wand2, Skull, HelpCircle, X } from 'lucide-react';
import { db, saveLocal } from '../db.js';
import { TopBar, EarTag, StockTag, statusColor } from '../components/Shell.jsx';
import { calcAge } from '../ageUtils.js';
import { estimateWeight } from '../weightEstimate.js';
import { SPECIES, MONTHS, BREEDS_BY_SPECIES, VACCINES, CONDITIONS, SYMPTOMS, TREATMENTS_GIVEN, DEATH_CAUSES, LOSS_CIRCUMSTANCES, INACTIVE_STATUSES } from '../constants.js';
import SpeciesIcon from '../components/SpeciesIcon.jsx';
import ImageSlots from '../components/ImageSlots.jsx';

export default function AnimalDetail({ animalId, onBack, onSelectAnimal, syncStatus, pending, onSyncTap }) {
  const [showSaleForm, setShowSaleForm] = useState(false);
  const [showVaxForm, setShowVaxForm] = useState(false);
  const [showTreatmentForm, setShowTreatmentForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showDeathForm, setShowDeathForm] = useState(false);
  const [showLostForm, setShowLostForm] = useState(false);
  const animal = useLiveQuery(() => db.animals.get(animalId), [animalId], null);
  const mother = useLiveQuery(() => animal?.motherId ? db.animals.get(animal.motherId) : null, [animal?.motherId], null);
  const offspring = useLiveQuery(
    () => db.animals.filter(a => a.motherId === animalId && !a.deleted).toArray(),
    [animalId],
    []
  );
  const relatedTasks = useLiveQuery(
    () => db.tasks.filter(t => t.animalId === animalId && !t.deleted).toArray(),
    [animalId],
    []
  );
  const relatedLedger = useLiveQuery(
    () => db.ledger.filter(l => l.animalId === animalId && !l.deleted).toArray(),
    [animalId],
    []
  );

  if (!animal) return null;

  const toggleTaskDone = async (t) => {
    await saveLocal('tasks', { ...t, done: !t.done });
  };

  const born = animal.birthMonth || animal.birthYear
    ? [animal.birthMonth, animal.birthYear].filter(Boolean).join(' ')
    : null;
  const computedAge = calcAge(animal.birthYear, animal.birthMonth);
  const vaccinations = [...(animal.vaccinations || [])].sort((a, b) => (a.date < b.date ? 1 : -1));
  const treatments = [...(animal.treatments || [])].sort((a, b) => (a.date < b.date ? 1 : -1));

  const markRecovered = async () => {
    const treatments = [...(animal.treatments || []), { condition: 'Recovered', treatment: '', date: new Date().toISOString().slice(0, 10) }];
    await saveLocal('animals', { ...animal, treatments, status: 'Healthy' });
  };

  const markFound = async () => {
    await saveLocal('animals', { ...animal, status: 'Healthy' });
  };

  return (
    <div className="flex flex-col h-full relative">
      <TopBar title="Animal record" onBack={onBack} syncStatus={syncStatus} pending={pending} onSyncTap={onSyncTap} />
      <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-4">
        {animal.images?.length > 0 && (
          <div className="grid grid-cols-3 gap-2">
            {animal.images.map((img, i) => (
              <div key={i} className="aspect-square rounded-lg overflow-hidden border border-border">
                <img src={img} alt="" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        )}

        <div className="bg-white rounded-lg border border-border p-4">
          <div className="flex items-start justify-between">
            <EarTag id={animal.id} />
            {!INACTIVE_STATUSES.includes(animal.status) && (
              <button onClick={() => setShowEditForm(true)} className="text-muted p-1 -mr-1 -mt-1" aria-label="Edit animal details">
                <Pencil size={16} />
              </button>
            )}
          </div>
          <div className="flex items-center gap-2 mt-2">
            <SpeciesIcon species={animal.species} size={22} />
            <div className="font-serif text-xl text-ink">{animal.breed} {animal.species}</div>
          </div>
          <span className={`inline-block text-[10px] font-medium px-2 py-1 rounded-full mt-2 ${statusColor[animal.status] || 'bg-muted text-white'}`}>
            {animal.status}
          </span>
        </div>

        <div className="bg-white rounded-lg border border-border divide-y divide-parchment">
          {[
            ['Sex', animal.sex],
            ['Age', computedAge || animal.age],
            ['Born', born],
            ['Weight', animal.weight],
            ['Stock brand', animal.brand],
            ['Feed', animal.feed],
            ['Last vaccination', animal.lastVax],
            ...(animal.mortality ? [['Cause of death', animal.mortality.cause], ['Date of death', animal.mortality.date]] : []),
            ...(animal.lossRecord ? [['Circumstances', animal.lossRecord.circumstance], ['Date lost', animal.lossRecord.date]] : []),
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between px-4 py-2.5 text-[13px]">
              <span className="text-muted">{k}</span>
              <span className="text-ink font-medium">{v || '—'}</span>
            </div>
          ))}
          {mother && (
            <button onClick={() => onSelectAnimal(mother.id)} className="w-full flex justify-between px-4 py-2.5 text-[13px]">
              <span className="text-muted">Mother</span>
              <span className="text-teal font-medium">{mother.id}</span>
            </button>
          )}
        </div>

        {treatments.length > 0 && (
          <div>
            <div className="text-[11px] text-muted mb-2 uppercase tracking-wide flex items-center gap-1.5">
              <Stethoscope size={12} /> Sickness &amp; treatment history
            </div>
            <div className="space-y-2">
              {treatments.map((t, i) => (
                <div key={i} className="bg-white rounded-lg border border-border p-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] text-ink font-medium">{t.condition}</span>
                    <span className="text-[11px] text-muted">{t.date}</span>
                  </div>
                  {t.treatment && <div className="text-[11px] text-muted mt-0.5">Treated with: {t.treatment}</div>}
                </div>
              ))}
            </div>
          </div>
        )}

        {vaccinations.length > 0 && (
          <div>
            <div className="text-[11px] text-muted mb-2 uppercase tracking-wide flex items-center gap-1.5">
              <Syringe size={12} /> Vaccination history
            </div>
            <div className="space-y-2">
              {vaccinations.map((v, i) => (
                <div key={i} className="bg-white rounded-lg border border-border p-2.5 flex items-center justify-between">
                  <span className="text-[12px] text-ink">{v.name}</span>
                  <span className="text-[11px] text-muted">{v.date}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {offspring.length > 0 && (
          <div>
            <div className="text-[11px] text-muted mb-2 uppercase tracking-wide">Offspring</div>
            <div className="space-y-2">
              {offspring.map(child => (
                <button
                  key={child.id}
                  onClick={() => onSelectAnimal(child.id)}
                  className="w-full text-left bg-white rounded-lg border border-border p-2.5 flex items-center justify-between"
                >
                  <div>
                    <EarTag id={child.id} size="sm" />
                    <div className="text-[12px] text-ink mt-1">{child.breed} · {calcAge(child.birthYear, child.birthMonth) || child.age}</div>
                  </div>
                  <span className={`text-[10px] font-medium px-2 py-1 rounded-full ${statusColor[child.status] || 'bg-muted text-white'}`}>{child.status}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {(relatedTasks.length > 0 || relatedLedger.length > 0) && (
          <div className="space-y-3">
            {relatedTasks.length > 0 && (
              <div>
                <div className="text-[11px] text-muted mb-2 uppercase tracking-wide flex items-center gap-1.5">
                  <ClipboardList size={12} /> Related tasks
                </div>
                <div className="space-y-2">
                  {relatedTasks.map(t => (
                    <button
                      key={t.id}
                      onClick={() => toggleTaskDone(t)}
                      className="w-full text-left bg-white rounded-lg border border-border p-2.5 flex items-center gap-2"
                    >
                      <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${t.done ? 'bg-forest border-forest' : 'border-border'}`}>
                        {t.done && <Check size={10} className="text-white" />}
                      </div>
                      <div className="flex-1">
                        <div className={`text-[12px] ${t.done ? 'line-through text-muted' : 'text-ink'}`}>{t.title}</div>
                        <div className="text-[10px] text-muted">{t.due}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
            {relatedLedger.length > 0 && (
              <div>
                <div className="text-[11px] text-muted mb-2 uppercase tracking-wide flex items-center gap-1.5">
                  <Wallet size={12} /> Related transactions
                </div>
                <div className="space-y-2">
                  {relatedLedger.map(l => (
                    <div key={l.id} className="bg-white rounded-lg border border-border p-2.5 flex items-center justify-between">
                      <div>
                        <div className="text-[12px] text-ink">{l.desc}</div>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[10px] text-muted">{l.date}</span>
                          {l.inventoryName && <StockTag name={l.inventoryName} size="sm" />}
                        </div>
                      </div>
                      <span className={`text-[12px] font-medium ${l.type === 'income' ? 'text-forest' : 'text-rust'}`}>
                        {l.type === 'income' ? '+' : '-'}N${l.amount.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {animal.status === 'Sick' && (
          <button onClick={markRecovered} className="w-full flex items-center justify-center gap-2 bg-forest text-white rounded-lg py-2.5 text-[13px] font-medium">
            <HeartPulse size={15} /> Mark as recovered
          </button>
        )}
        {animal.status === 'Lost' && (
          <button onClick={markFound} className="w-full flex items-center justify-center gap-2 bg-forest text-white rounded-lg py-2.5 text-[13px] font-medium">
            <HeartPulse size={15} /> Mark as found
          </button>
        )}
        {!INACTIVE_STATUSES.includes(animal.status) && (
          <>
            <button onClick={() => setShowVaxForm(true)} className="w-full flex items-center justify-center gap-2 bg-forest text-white rounded-lg py-2.5 text-[13px] font-medium">
              <Syringe size={15} /> Log vaccination
            </button>
            <button onClick={() => setShowTreatmentForm(true)} className="w-full flex items-center justify-center gap-2 bg-white border border-rust text-rust rounded-lg py-2.5 text-[13px] font-medium">
              <Stethoscope size={15} /> Log sickness / treatment
            </button>
            <button onClick={() => setShowSaleForm(true)} className="w-full flex items-center justify-center gap-2 bg-leather text-white rounded-lg py-2.5 text-[13px] font-medium">
              <BadgeDollarSign size={15} /> Log sale
            </button>
            <button onClick={() => setShowLostForm(true)} className="w-full flex items-center justify-center gap-2 bg-white border border-muted text-muted rounded-lg py-2.5 text-[13px] font-medium">
              <HelpCircle size={15} /> Log lost / missing
            </button>
            <button onClick={() => setShowDeathForm(true)} className="w-full flex items-center justify-center gap-2 bg-ink text-white rounded-lg py-2.5 text-[13px] font-medium">
              <Skull size={15} /> Log death
            </button>
          </>
        )}
        {animal.status === 'Sold' && (
          <div className="text-center text-[12px] text-muted py-1">This animal is marked as sold.</div>
        )}
        {animal.status === 'Deceased' && (
          <div className="text-center text-[12px] text-muted py-1">
            This animal is marked deceased.{' '}
            <button onClick={() => saveLocal('animals', { ...animal, status: 'Healthy' })} className="text-teal underline">
              This was a mistake
            </button>
          </div>
        )}
      </div>
      {showSaleForm && <SaleForm animal={animal} onClose={() => setShowSaleForm(false)} />}
      {showVaxForm && <VaccinationForm animal={animal} onClose={() => setShowVaxForm(false)} />}
      {showTreatmentForm && <TreatmentForm animal={animal} onClose={() => setShowTreatmentForm(false)} />}
      {showEditForm && <EditAnimalForm animal={animal} onClose={() => setShowEditForm(false)} />}
      {showDeathForm && <DeathForm animal={animal} onClose={() => setShowDeathForm(false)} />}
      {showLostForm && <LostForm animal={animal} onClose={() => setShowLostForm(false)} />}
    </div>
  );
}

function DeathForm({ animal, onClose }) {
  const [cause, setCause] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [notes, setNotes] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (!cause) return;
    await saveLocal('animals', { ...animal, status: 'Deceased', mortality: { cause, date, notes } });
    onClose();
  };

  return (
    <div className="absolute inset-0 bg-ink/40 flex items-end">
      <div className="w-full bg-parchment rounded-t-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-lg text-ink">Log death — {animal.id}</h2>
          <button onClick={onClose}><X size={18} className="text-muted" /></button>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <label className="block">
            <span className="text-[11px] text-muted">Cause of death</span>
            <select value={DEATH_CAUSES.includes(cause) ? cause : (cause ? 'Other' : '')} onChange={(e) => setCause(e.target.value === 'Other' ? '' : e.target.value)} className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest">
              <option value="">Select a cause</option>
              {DEATH_CAUSES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            {(cause === '' || !DEATH_CAUSES.includes(cause)) && (
              <input
                value={DEATH_CAUSES.includes(cause) ? '' : cause}
                onChange={(e) => setCause(e.target.value)}
                placeholder="Cause of death"
                className="mt-2 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
              />
            )}
          </label>
          <label className="block">
            <span className="text-[11px] text-muted">Date</span>
            <input
              type="date" value={date} onChange={(e) => setDate(e.target.value)}
              className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
            />
          </label>
          <label className="block">
            <span className="text-[11px] text-muted">Notes (optional)</span>
            <input
              value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Any additional detail"
              className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
            />
          </label>
          <button type="submit" className="w-full bg-ink text-white rounded-lg py-2.5 text-[13px] font-medium mt-2">
            Save
          </button>
        </form>
      </div>
    </div>
  );
}

function LostForm({ animal, onClose }) {
  const [circumstance, setCircumstance] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [notes, setNotes] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (!circumstance) return;
    await saveLocal('animals', { ...animal, status: 'Lost', lossRecord: { circumstance, date, notes } });
    onClose();
  };

  return (
    <div className="absolute inset-0 bg-ink/40 flex items-end">
      <div className="w-full bg-parchment rounded-t-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-lg text-ink">Log lost / missing — {animal.id}</h2>
          <button onClick={onClose}><X size={18} className="text-muted" /></button>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <label className="block">
            <span className="text-[11px] text-muted">Circumstances</span>
            <select value={LOSS_CIRCUMSTANCES.includes(circumstance) ? circumstance : (circumstance ? 'Other' : '')} onChange={(e) => setCircumstance(e.target.value === 'Other' ? '' : e.target.value)} className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest">
              <option value="">Select circumstances</option>
              {LOSS_CIRCUMSTANCES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            {(circumstance === '' || !LOSS_CIRCUMSTANCES.includes(circumstance)) && (
              <input
                value={LOSS_CIRCUMSTANCES.includes(circumstance) ? '' : circumstance}
                onChange={(e) => setCircumstance(e.target.value)}
                placeholder="Circumstances"
                className="mt-2 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
              />
            )}
          </label>
          <label className="block">
            <span className="text-[11px] text-muted">Date last seen</span>
            <input
              type="date" value={date} onChange={(e) => setDate(e.target.value)}
              className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
            />
          </label>
          <label className="block">
            <span className="text-[11px] text-muted">Notes (optional)</span>
            <input
              value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Any additional detail"
              className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
            />
          </label>
          <button type="submit" className="w-full bg-muted text-white rounded-lg py-2.5 text-[13px] font-medium mt-2">
            Save
          </button>
        </form>
      </div>
    </div>
  );
}

function EditAnimalForm({ animal, onClose }) {
  const [form, setForm] = useState({
    species: animal.species || 'Cattle',
    breed: animal.breed || '',
    sex: animal.sex || 'Female',
    age: animal.age || '',
    weight: animal.weight || '',
    status: animal.status || 'Healthy',
    brand: animal.brand || '',
    feed: animal.feed || '',
    birthMonth: animal.birthMonth || '',
    birthYear: animal.birthYear || '',
  });
  const [images, setImages] = useState(animal.images || []);
  const currentYear = new Date().getFullYear();
  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));
  const feedOptions = useLiveQuery(() => db.inventory.filter(i => !i.deleted).toArray(), [], []);

  const submit = async (e) => {
    e.preventDefault();
    await saveLocal('animals', {
      ...animal,
      ...form,
      birthYear: form.birthYear ? Number(form.birthYear) : null,
      images,
    });
    onClose();
  };

  return (
    <div className="absolute inset-0 bg-ink/40 flex items-end">
      <div className="w-full bg-parchment rounded-t-2xl p-4 space-y-3 max-h-[90%] overflow-y-auto">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-lg text-ink">Edit {animal.id}</h2>
          <button onClick={onClose}><X size={18} className="text-muted" /></button>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <ImageSlots images={images} onChange={setImages} />
          <div className="grid grid-cols-2 gap-3">
            <EditSelect label="Species" value={form.species} onChange={set('species')} options={SPECIES} />
            <EditSelect label="Sex" value={form.sex} onChange={set('sex')} options={['Female', 'Male']} />
          </div>
          <label className="block">
            <span className="text-[11px] text-muted">Breed</span>
            <select value={form.breed} onChange={set('breed')} className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest">
              <option value="">Not set</option>
              {(BREEDS_BY_SPECIES[form.species] || ['Other']).map(b => <option key={b} value={b}>{b}</option>)}
              {form.breed && !(BREEDS_BY_SPECIES[form.species] || []).includes(form.breed) && (
                <option value={form.breed}>{form.breed}</option>
              )}
            </select>
            {form.breed === 'Other' && (
              <input
                placeholder="Breed name"
                onChange={(e) => setForm(f => ({ ...f, breed: e.target.value }))}
                className="mt-2 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
              />
            )}
          </label>
          <div className="grid grid-cols-2 gap-3">
            <EditSelect label="Birth month" value={form.birthMonth} onChange={set('birthMonth')} options={['', ...MONTHS]} display={(m) => m || 'Unknown'} />
            <EditSelect
              label="Birth year" value={form.birthYear} onChange={set('birthYear')}
              options={['', ...Array.from({ length: 25 }, (_, i) => currentYear - i)]}
              display={(y) => y || 'Unknown'}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <EditField label="Age (if birth date unknown)" value={form.age} onChange={set('age')} placeholder="e.g. 2y, 3mo" />
            <div>
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-muted">Weight</span>
                {form.birthYear && (
                  <button
                    type="button"
                    onClick={() => {
                      const est = estimateWeight(form.species, form.breed, form.birthYear, form.birthMonth, MONTHS);
                      if (est) setForm(f => ({ ...f, weight: `${est}kg (est.)` }));
                    }}
                    className="text-[10px] text-teal flex items-center gap-0.5"
                  >
                    <Wand2 size={10} /> Estimate
                  </button>
                )}
              </div>
              <input
                value={form.weight} onChange={set('weight')} placeholder="e.g. 210kg"
                className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
              />
            </div>
          </div>
          <EditSelect label="Status" value={form.status} onChange={set('status')} options={['Healthy', 'Vax due', 'Pregnant', 'Sick']} />
          <EditField label="Stock brand" value={form.brand} onChange={set('brand')} placeholder="e.g. OF/24" />
          <label className="block">
            <span className="text-[11px] text-muted">Feed being used</span>
            <select value={form.feed} onChange={set('feed')} className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest">
              <option value="">Not set</option>
              {feedOptions.map(f => <option key={f.id} value={f.name}>{f.name}</option>)}
              {form.feed && !feedOptions.some(f => f.name === form.feed) && <option value={form.feed}>{form.feed}</option>}
            </select>
          </label>
          <button type="submit" className="w-full bg-forest text-parchment rounded-lg py-2.5 text-[13px] font-medium mt-2">
            Save changes
          </button>
        </form>
      </div>
    </div>
  );
}

function EditField({ label, ...props }) {
  return (
    <label className="block">
      <span className="text-[11px] text-muted">{label}</span>
      <input {...props} className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest" />
    </label>
  );
}

function EditSelect({ label, options, display, ...props }) {
  return (
    <label className="block">
      <span className="text-[11px] text-muted">{label}</span>
      <select {...props} className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest">
        {options.map(o => <option key={o} value={o}>{display ? display(o) : o}</option>)}
      </select>
    </label>
  );
}

function VaccinationForm({ animal, onClose }) {
  const [name, setName] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));

  const submit = async (e) => {
    e.preventDefault();
    if (!name) return;
    const vaccinations = [...(animal.vaccinations || []), { name, date }];
    await saveLocal('animals', { ...animal, vaccinations, lastVax: date, status: animal.status === 'Sick' ? 'Sick' : 'Healthy' });
    onClose();
  };

  return (
    <div className="absolute inset-0 bg-ink/40 flex items-end">
      <div className="w-full bg-parchment rounded-t-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-lg text-ink">Log vaccination — {animal.id}</h2>
          <button onClick={onClose}><X size={18} className="text-muted" /></button>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <label className="block">
            <span className="text-[11px] text-muted">Vaccine name</span>
            <select value={VACCINES.includes(name) ? name : (name ? 'Other' : '')} onChange={(e) => setName(e.target.value === 'Other' ? '' : e.target.value)} className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest">
              <option value="">Select a vaccine</option>
              {VACCINES.map(v => <option key={v} value={v}>{v}</option>)}
            </select>
            {(name === '' || !VACCINES.includes(name)) && (
              <input
                value={VACCINES.includes(name) ? '' : name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Vaccine name"
                className="mt-2 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
              />
            )}
          </label>
          <label className="block">
            <span className="text-[11px] text-muted">Date</span>
            <input
              type="date" value={date} onChange={(e) => setDate(e.target.value)}
              className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
            />
          </label>
          <button type="submit" className="w-full bg-forest text-parchment rounded-lg py-2.5 text-[13px] font-medium mt-2">
            Save vaccination
          </button>
        </form>
      </div>
    </div>
  );
}

function TreatmentForm({ animal, onClose }) {
  const [condition, setCondition] = useState('');
  const [symptom, setSymptom] = useState('');
  const [treatment, setTreatment] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [recovered, setRecovered] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    if (!condition) return;
    const fullCondition = symptom ? `${condition} (${symptom})` : condition;
    const treatments = [...(animal.treatments || []), { condition: fullCondition, treatment, date }];
    await saveLocal('animals', { ...animal, treatments, status: recovered ? 'Healthy' : 'Sick' });
    onClose();
  };

  return (
    <div className="absolute inset-0 bg-ink/40 flex items-end">
      <div className="w-full bg-parchment rounded-t-2xl p-4 space-y-3 max-h-[88%] overflow-y-auto">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-lg text-ink">Log sickness / treatment — {animal.id}</h2>
          <button onClick={onClose}><X size={18} className="text-muted" /></button>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <label className="block">
            <span className="text-[11px] text-muted">Condition</span>
            <select value={CONDITIONS.includes(condition) ? condition : (condition ? 'Other' : '')} onChange={(e) => setCondition(e.target.value === 'Other' ? '' : e.target.value)} className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest">
              <option value="">Select a condition</option>
              {CONDITIONS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            {(condition === '' || !CONDITIONS.includes(condition)) && (
              <input
                value={CONDITIONS.includes(condition) ? '' : condition}
                onChange={(e) => setCondition(e.target.value)}
                placeholder="Condition"
                className="mt-2 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
              />
            )}
          </label>
          <label className="block">
            <span className="text-[11px] text-muted">Symptom (optional)</span>
            <select value={SYMPTOMS.includes(symptom) ? symptom : (symptom ? 'Other' : '')} onChange={(e) => setSymptom(e.target.value === 'Other' ? '' : e.target.value)} className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest">
              <option value="">None</option>
              {SYMPTOMS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            {symptom === 'Other' || (symptom !== '' && !SYMPTOMS.includes(symptom)) ? (
              <input
                value={SYMPTOMS.includes(symptom) ? '' : symptom}
                onChange={(e) => setSymptom(e.target.value)}
                placeholder="Symptom"
                className="mt-2 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
              />
            ) : null}
          </label>
          <label className="block">
            <span className="text-[11px] text-muted">Treatment given (optional)</span>
            <select value={TREATMENTS_GIVEN.includes(treatment) ? treatment : (treatment ? 'Other' : '')} onChange={(e) => setTreatment(e.target.value === 'Other' ? '' : e.target.value)} className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest">
              <option value="">None</option>
              {TREATMENTS_GIVEN.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
            {treatment === 'Other' || (treatment !== '' && !TREATMENTS_GIVEN.includes(treatment)) ? (
              <input
                value={TREATMENTS_GIVEN.includes(treatment) ? '' : treatment}
                onChange={(e) => setTreatment(e.target.value)}
                placeholder="Treatment given"
                className="mt-2 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
              />
            ) : null}
          </label>
          <label className="block">
            <span className="text-[11px] text-muted">Date</span>
            <input
              type="date" value={date} onChange={(e) => setDate(e.target.value)}
              className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
            />
          </label>
          <label className="flex items-center gap-2 text-[13px] text-ink">
            <input type="checkbox" checked={recovered} onChange={(e) => setRecovered(e.target.checked)} className="w-4 h-4" />
            Animal has recovered (marks as Healthy)
          </label>
          <button type="submit" className="w-full bg-rust text-white rounded-lg py-2.5 text-[13px] font-medium mt-2">
            Save entry
          </button>
        </form>
      </div>
    </div>
  );
}

function SaleForm({ animal, onClose }) {
  const [amount, setAmount] = useState('');
  const [buyer, setBuyer] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));

  const submit = async (e) => {
    e.preventDefault();
    if (!amount) return;

    await saveLocal('ledger', {
      id: crypto.randomUUID(),
      desc: `Sold ${animal.breed || animal.species} ${animal.id}${buyer ? ` to ${buyer}` : ''}`,
      amount: Number(amount),
      type: 'income',
      date,
      animalId: animal.id,
      inventoryId: null,
      inventoryName: null,
    });
    await saveLocal('animals', { ...animal, status: 'Sold' });
    onClose();
  };

  return (
    <div className="absolute inset-0 bg-ink/40 flex items-end">
      <div className="w-full bg-parchment rounded-t-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-lg text-ink">Log sale — {animal.id}</h2>
          <button onClick={onClose}><X size={18} className="text-muted" /></button>
        </div>
        <p className="text-[12px] text-muted">
          This adds an income entry to Finances and marks the animal as sold.
        </p>
        <form onSubmit={submit} className="space-y-3">
          <label className="block">
            <span className="text-[11px] text-muted">Sale amount (N$)</span>
            <input
              type="number" value={amount} onChange={(e) => setAmount(e.target.value)} required
              className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
            />
          </label>
          <label className="block">
            <span className="text-[11px] text-muted">Buyer (optional)</span>
            <input
              value={buyer} onChange={(e) => setBuyer(e.target.value)} placeholder="e.g. Meatco, private buyer"
              className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
            />
          </label>
          <label className="block">
            <span className="text-[11px] text-muted">Date</span>
            <input
              type="date" value={date} onChange={(e) => setDate(e.target.value)}
              className="mt-1 w-full bg-white border border-border rounded-lg px-3 py-2 text-[13px] text-ink outline-none focus:border-forest"
            />
          </label>
          <button type="submit" className="w-full bg-leather text-white rounded-lg py-2.5 text-[13px] font-medium mt-2">
            Confirm sale
          </button>
        </form>
      </div>
    </div>
  );
}
